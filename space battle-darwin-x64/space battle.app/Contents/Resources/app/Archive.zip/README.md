# Battle Ship
created as a theory now, I'm going full in trying to build a quick and fun game to play on any desktop device.
## global packages
`npm install -g electron browserify`

## run app
1. install all dependencies
`npm install`
2. run app
`npm test`

## todos
- [x] Create player
- [x] Spin player 360°
- [x] play music 
- [ ] Shoot lazer
- [x] Show score 
- [x] Show health
- [ ] Create aliens in random corners
- [ ] Aliens fly towards player
- [ ] Alien shot add xp
- [ ] Alien shot loose health
- [ ] Alien hit player, player loose health
